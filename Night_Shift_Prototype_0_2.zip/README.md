# Night Shift: 2 A.M. — Prototype 0.2

This is the first real multiplayer foundation for the game.

## What it currently does

- Browser-based game screen
- Create a 4-character room
- Join an existing room
- Exactly two players per room
- Parent A and Parent B
- Keyboard controls
- Touch controls for phones/tablets
- Real-time player movement through Socket.IO
- Automatic disconnect handling

## Run it

This project needs a host that supports Node.js.

1. Upload the whole project folder.
2. Run `npm install`.
3. Run `npm start`.
4. Open the public URL.
5. Player 1 chooses Create Game.
6. Player 2 opens the same URL and chooses Join Game.
7. Enter the 4-character room code.

## Important

This is intentionally not the finished game. It proves the multiplayer foundation before we add the house, children, sleep meters, ghost, and gameplay loop.
